# @vixo/platform-contracts

Contratos de solo lectura compartidos entre el Shell y los MFE de dominio.
Reglas: `creacion_conocimiento_mfe/shell/10-identity-propagation.md` y `mfe-shell/04-shell-contract.md`.

| Export | Uso |
|---|---|
| `Role`, `ROLES`, `isRole` | Roles de la plataforma |
| `SessionUser`, `PlatformSession`, `PLATFORM_SESSION` | Sesión de solo lectura que provee el Shell |
| `MfeRegistryEntry` | Entrada del registro de MFE del Shell |
| `MfeRoutesModule` | Forma del módulo `./Routes` de un MFE de dominio |

## Uso local (sin registry npm)

```bash
npm run pack:local          # genera vixo-platform-contracts-1.0.0.tgz
```

En cada proyecto consumidor:

```bash
npm install ../platform-contracts/vixo-platform-contracts-1.0.0.tgz
```

Native Federation lo comparte como singleton (está en `dependencies`), así que el Shell y los MFE usan
la misma instancia de `PLATFORM_SESSION`. Shell y MFE deben usar la **misma versión** del paquete.
